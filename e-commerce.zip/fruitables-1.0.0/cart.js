// Initialize cart array to store items
let cart = [];

// Function to add an item to the cart
function addToCart(name, price) {
    // Create a new item object
    let item = {
        name: name,
        price: price
    };

    // Add the item to the cart array
    cart.push(item);

    // Store the cart array in the session storage
    sessionStorage.setItem('cart', JSON.stringify(cart));

    // Update the cart icon
    updateCartIcon();

    // Optional: Display a confirmation message
    alert('Item added to cart!');
}

// Function to update the cart icon
function updateCartIcon() {
    let cartIcon = document.querySelector('.cart-icon');
    if (cartIcon) {
        let cartItemCount = cart.length;
        cartIcon.textContent = cartItemCount;
    }
}

// Event delegation for "Add to Cart" buttons
document.addEventListener('DOMContentLoaded', function() {
    document.body.addEventListener('click', function(event) {
        if (event.target.classList.contains('add-to-cart')) {
            let productName = event.target.getAttribute('data-product-name');
            let productPrice = event.target.getAttribute('data-product-price');
            addToCart(productName, productPrice);
        }
    });

    // Update the cart icon on page load
    updateCartIcon();
});
